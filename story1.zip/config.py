

SQLALCHEMY_DATABASE_URI = "sqlite:///database.db"



ADMIN_USERNAME = "fari"
ADMIN_PASSWORD = "1234"